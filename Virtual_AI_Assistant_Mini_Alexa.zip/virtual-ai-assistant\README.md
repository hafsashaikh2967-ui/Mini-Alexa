# Virtual AI Assistant (Mini Alexa)

## Project Overview

Mini Alexa is a simple terminal-based virtual AI assistant developed using Python.

The assistant uses rule-based programming and basic AI concepts to respond to user commands.

## Features

- User name recognition
- Greeting responses
- Current date
- Current time
- Basic calculator
- Random quotes
- Random jokes
- Random facts
- Number guessing game
- Help menu
- Rule-based recommendations
- Simplified perceptron demonstration
- Graceful exit
- Fallback response for unknown commands

## Technologies Used

- Python
- Python Standard Library
- datetime module
- random module

## How to Run

1. Install Python.
2. Open the project folder in VS Code.
3. Open the terminal.
4. Run:

```text
python main.py