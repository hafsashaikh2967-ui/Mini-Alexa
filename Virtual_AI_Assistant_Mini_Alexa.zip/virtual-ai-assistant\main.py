from datetime import datetime
import random

print("===================================")
print("     MINI ALEXA - VIRTUAL ASSISTANT")
print("===================================")

print("Assistant: Hi! I'm Mini Alexa.")

name = input("Assistant: What's your name? ")

print(f"Assistant: Nice to meet you, {name}!")
print("Assistant: Type 'help' to see what I can do.")

while True:

    command = input(f"{name}: ").lower().strip()

    # Exit
    if command == "exit":
        print(f"Assistant: Goodbye, {name}! Have a great day.")
        break

    # Help
    elif command == "help":
        print("Assistant: Here are the commands I can understand:")
        print("  time       - Show the current time")
        print("  date       - Show today's date")
        print("  calculate  - Perform a calculation")
        print("  quote      - Give a random quote")
        print("  joke       - Tell a random joke")
        print("  fact       - Give a random fact")
        print("  guess      - Play the number guessing game")
        print("  recommend  - Get a recommendation")
        print("  perceptron - Run a simple perceptron")
        print("  help       - Show this help menu")
        print("  exit       - Exit Mini Alexa")

    # Greetings
    elif command in ["hi", "hello", "hey"]:
        print(f"Assistant: Hello {name}! How can I help you?")

    # Time
    elif command == "time":
        current_time = datetime.now().strftime("%I:%M %p")
        print(f"Assistant: The current time is {current_time}.")

    # Date
    elif command == "date":
        current_date = datetime.now().strftime("%d %B %Y")
        print(f"Assistant: Today's date is {current_date}.")

    # Calculator
    elif command == "calculate":
        try:
            num1 = float(input("Assistant: Enter first number: "))
            operator = input("Assistant: Enter operator (+, -, *, /): ")
            num2 = float(input("Assistant: Enter second number: "))

            if operator == "+":
                result = num1 + num2
            elif operator == "-":
                result = num1 - num2
            elif operator == "*":
                result = num1 * num2
            elif operator == "/":
                if num2 == 0:
                    print("Assistant: Cannot divide by zero.")
                    continue
                result = num1 / num2
            else:
                print("Assistant: Invalid operator.")
                continue

            print(f"Assistant: The answer is {result}.")

        except ValueError:
            print("Assistant: Please enter valid numbers.")
    # Random Quote
    elif command == "quote":
        quotes = [
            "Believe in yourself.",
            "Every day is a new beginning.",
            "Success comes from consistent effort.",
            "Dream big and never give up.",
            "Small steps lead to big achievements."
        ]

        print(f"Assistant: {random.choice(quotes)}.")

    # Random Joke
    elif command == "joke":
        jokes = [
            "Why did the computer go to the doctor? Because it had a virus!",
            "Why was the computer cold? Because it left its Windows open!",
            "Why do programmers prefer dark mode? Because light attracts bugs!",
            "What do you call a computer that sings? A Dell!",
            "Why did the smartphone need glasses? Because it lost its contacts!"
        ]

        print(f"Assistant: {random.choice(jokes)}")

    # Random Fact
    elif command == "fact":
        facts = [
            "Python was created by Guido van Rossum.",
            "The Earth revolves around the Sun.",
            "Water covers about 71 percent of Earth's surface.",
            "The human brain has billions of neurons.",
            "The first computer mouse was made of wood."
        ]

        print(f"Assistant: {random.choice(facts)}")

    # Number Guessing Game
    elif command == "guess":
        secret_number = random.randint(1, 10)

        print("Assistant: I have chosen a number between 1 and 10.")
        print("Assistant: Try to guess it!")

        while True:
            guess = int(input("Assistant: Enter your guess: "))

            if guess < secret_number:
                print("Assistant: Higher!")
            elif guess > secret_number:
                print("Assistant: Lower!")
            else:
                print("Assistant: Correct! You guessed it!")
                break

    # Rule-Based Recommendation
    elif command == "recommend":
        preference = input(
            "Assistant: What do you like? (music, movies, books): "
        ).lower().strip()

        if preference == "music":
            print("Assistant: I recommend listening to some relaxing music.")
        elif preference == "movies":
            print("Assistant: I recommend watching a comedy movie.")
        elif preference == "books":
            print("Assistant: I recommend reading a motivational book.")
        else:
            print("Assistant: I recommend exploring something new!")

    # Simplified Perceptron
    elif command == "perceptron":
        x1 = float(input("Assistant: Enter input 1 (0 or 1): "))
        x2 = float(input("Assistant: Enter input 2 (0 or 1): "))

        w1 = 0.5
        w2 = 0.5
        bias = -0.5

        weighted_sum = (x1 * w1) + (x2 * w2) + bias

        if weighted_sum >= 0:
            output = 1
        else:
            output = 0

        print(f"Assistant: Weighted sum = {weighted_sum}")
        print(f"Assistant: Perceptron output = {output}")

    # Fallback
    else:
        print("Assistant: I'm not sure I understood that.")
        print("Assistant: Type 'help' to see the commands I can understand.")